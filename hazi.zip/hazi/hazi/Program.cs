﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace hazi
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Kérem adja meg a tömb elemeinek a számát:");
            int egy = Convert.ToInt32(Console.ReadLine());
            int[] tomb = new int[egy];

            Console.WriteLine(""érem adja meg a tömb elemeit""
        }
    }
}
