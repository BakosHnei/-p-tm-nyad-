﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace megintvalamiszar
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
           
           

           Random rnd = new Random();   
            int random=rnd.Next(1, 101);
            bool kitalalta = false;
            int tippek_szama = 0;

            Console.WriteLine("Ez egy számkitalálos játékprogram!");
            Console.WriteLine("Találd ki a gép által generált random számot! ");
            
            while (true) {

                Console.WriteLine("Add meg az első tipped:");
                string tipp = Console.ReadLine();

             if  (int.TryParse(tipp, out int felhasznalotippje))
                {
                    if (felhasznalotippje == random) 
                    {
                       kitalalta=true;
                        Console.WriteLine("Gratu, a tipped helyes! A szám: {random} ");
                        Console.WriteLine("Probálkozások száma:{tippek_szama}");
                    }
                    else if(felhasznalotippje < random)
                    {
                        Console.WriteLine("A szám kisebb.");
                    }
                }
            }

            Console.ReadKey();

        }
    }
}
